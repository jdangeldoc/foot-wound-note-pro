@echo off
powershell -Command "Compress-Archive -Path 'C:\PatientSummaries\*' -DestinationPath 'C:\PatientSummaries.zip'"
powershell -Command "Send-MailMessage -To 'admin@hospital.org' -From 'you@hospital.org' -Subject 'Daily Summary' -Body 'Attached.' -SmtpServer 'smtp.hospital.org' -Attachments 'C:\PatientSummaries.zip'"
