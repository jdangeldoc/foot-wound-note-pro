@echo off
set "SOURCE=C:\ScannedPDFs"
set "DEST=C:\MasterLog\PDFs"
xcopy "%SOURCE%" "%DEST%" /E /Y
echo PDF log update completed.
pause
