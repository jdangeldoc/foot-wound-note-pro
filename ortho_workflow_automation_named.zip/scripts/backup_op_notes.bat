@echo off
set "SOURCE=C:\OperativeNotes"
set "DEST=D:\Backups\OperativeNotes"
xcopy "%SOURCE%" "%DEST%" /E /Y
echo Backup completed.
pause
