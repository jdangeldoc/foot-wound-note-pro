@echo off
robocopy "C:\EMR\Exports" "C:\OneDrive\EMR_Sync" /MIR
echo Sync complete.
pause
