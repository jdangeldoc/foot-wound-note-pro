# Task Scheduler Setup

1. Open Task Scheduler → Create Task
2. Trigger: Daily or on Event (e.g., USB inserted)
3. Action: Start a Program → select .bat file
4. Conditions: Uncheck 'Start only if idle'
5. Run with highest privileges
