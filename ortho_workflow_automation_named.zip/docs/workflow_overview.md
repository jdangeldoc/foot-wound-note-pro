# Orthopedic Workflow Automation Scripts

## Purpose:
Automate routine post-op tasks like:
- Backups
- EMR sync
- PDF logging
- Case summary emailing

## Suggested Schedule:
- Backup: Daily 7:00 PM
- Sync: After each clinic
- Email: 4:00 PM before end of day
