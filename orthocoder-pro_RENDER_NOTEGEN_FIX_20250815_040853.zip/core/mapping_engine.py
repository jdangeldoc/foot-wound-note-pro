from __future__ import annotations
import math
import pandas as pd
from typing import List, Dict, Any

# Debridement tiers (cm2) per depth
DEBRIDE_TABLE = {
    "Subcutaneous Tissue": {"base": ("11042", 20), "add": ("11045", 20)},
    "Fascia/Muscle": {"base": ("11043", 20), "add": ("11046", 20)},
    "Bone": {"base": ("11044", 20), "add": ("11047", 20)},
}

INFECTION_ICD = {
    "Abscess": ["L02.419"],
    "Cellulitis": ["L03.119"],
    "Osteomyelitis (acute)": ["M86.10"],
    "Osteomyelitis (chronic)": ["M86.60"],
    "Diabetic foot ulcer": ["E11.621","L97.509"],
    "Septic arthritis": ["M00.9"],
    "None": []
}

def _round_up_units(area_cm2: float, unit: int) -> int:
    if area_cm2 <= 0:
        return 0
    if area_cm2 <= unit:
        return 0
    remaining = max(0.0, area_cm2 - unit)
    return math.ceil(remaining / unit)

def _codes_for_debridement_totals(total_by_depth: Dict[str, float]) -> List[str]:
    codes = []
    for depth, total_area in total_by_depth.items():
        if depth not in DEBRIDE_TABLE:
            continue
        base_code, base_unit = DEBRIDE_TABLE[depth]["base"]
        add_code, add_unit = DEBRIDE_TABLE[depth]["add"]
        if total_area > 0:
            codes.append(base_code)
            n_add = _round_up_units(total_area, add_unit)
            codes.extend([add_code] * n_add)
    return codes

def _codes_for_ind(wounds_df: pd.DataFrame) -> List[str]:
    ind_rows = wounds_df[wounds_df["procedure"] == "Incision & Drainage"]
    if ind_rows.empty:
        return []
    multiple = ind_rows.shape[0] > 1
    if not multiple:
        r = ind_rows.iloc[0]
        if str(r.get("contamination", "")).lower() == "infected" and float(r.get("area_cm2", 0) or 0) > 5.0:
            multiple = True
    return ["10061"] if multiple else ["10060"]

def _codes_for_joint_injection(wounds_df: pd.DataFrame) -> List[str]:
    if wounds_df[wounds_df["procedure"] == "Joint Injection"].empty:
        return []
    return ["20610"]

def _codes_for_foreign_body_removal(wounds_df: pd.DataFrame) -> List[str]:
    if wounds_df[wounds_df["procedure"] == "Foreign Body Removal"].empty:
        return []
    return ["10120"]

def _codes_for_wound_closure(wounds_df: pd.DataFrame) -> List[str]:
    if wounds_df[wounds_df["procedure"] == "Wound Closure"].empty:
        return []
    return ["12031"]

def _icd10_from_packs(packs: List[str]) -> List[str]:
    codes = []
    if any("Diabetes" in p for p in packs):
        codes += ["E11.42"]
    if any("PVD + Ulcer" == p for p in packs):
        codes += ["I73.9", "L97.509"]
    if any("PVD + Gangrene" == p for p in packs):
        codes += ["I73.9", "I70.269"]
    if any("Smoker" == p for p in packs):
        codes += ["Z72.0"]
    if any("Chronic Kidney Disease" == p for p in packs):
        codes += ["N18.9"]
    if any("Heart Failure" in p for p in packs):
        codes += ["I50.30"]
    out = []
    for c in codes:
        if c not in out: out.append(c)
    return out

def suggest_icd10_from_rows(rows: List[Dict[str, Any]], packs: List[str]) -> List[str]:
    codes = []
    any_infected = any(str(r.get("contamination","")).lower()=="infected" for r in rows)
    for r in rows:
        codes += INFECTION_ICD.get(r.get("infection_type","None"), [])
    if any_infected and "L08.9" not in codes:
        codes.append("L08.9")
    codes += _icd10_from_packs(packs)
    out = []
    for c in codes:
        if c and c not in out: out.append(c)
    return out

def compute_coding_bundle(wounds_df: pd.DataFrame, packs: List[str], override_icd10: List[str] | None = None) -> Dict[str, Any]:
    if wounds_df is None or wounds_df.empty:
        return {"totals": {"debridement_cm2": {"Subcutaneous Tissue":0.0,"Fascia/Muscle":0.0,"Bone":0.0},
                           "num_sites":0,"vascularity_counts":{},"contamination_counts":{}},
                "cpt_codes": [], "icd10_codes": []}
    wounds_df = wounds_df.copy()
    if "area_cm2" in wounds_df.columns:
        wounds_df["area_cm2"] = pd.to_numeric(wounds_df["area_cm2"], errors="coerce").fillna(0.0)

    totals_by_depth = {"Subcutaneous Tissue": 0.0, "Fascia/Muscle": 0.0, "Bone": 0.0}
    for _, row in wounds_df.iterrows():
        if str(row.get("procedure","")) == "Debridement":
            depth = str(row.get("depth",""))
            if depth in totals_by_depth:
                totals_by_depth[depth] += float(row.get("area_cm2",0.0) or 0.0)

    cpt_codes: List[str] = []
    cpt_codes += _codes_for_debridement_totals(totals_by_depth)
    cpt_codes += _codes_for_ind(wounds_df)
    cpt_codes += _codes_for_joint_injection(wounds_df)
    cpt_codes += _codes_for_foreign_body_removal(wounds_df)
    cpt_codes += _codes_for_wound_closure(wounds_df)

    if override_icd10 is not None:
        icd10_codes = list(dict.fromkeys([c for c in override_icd10 if c]))
    else:
        rows = wounds_df.to_dict("records")
        icd10_codes = suggest_icd10_from_rows(rows, packs)

    vasc_counts = wounds_df["vascularity"].value_counts(dropna=False).to_dict() if "vascularity" in wounds_df.columns else {}
    contam_counts = wounds_df["contamination"].value_counts(dropna=False).to_dict() if "contamination" in wounds_df.columns else {}

    return {
        "totals": {
            "debridement_cm2": totals_by_depth,
            "num_sites": int(wounds_df.shape[0]),
            "vascularity_counts": vasc_counts,
            "contamination_counts": contam_counts
        },
        "cpt_codes": cpt_codes,
        "icd10_codes": icd10_codes
    }
