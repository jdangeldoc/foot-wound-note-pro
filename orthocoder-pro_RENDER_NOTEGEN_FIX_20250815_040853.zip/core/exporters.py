from __future__ import annotations
import io, json
from docx import Document
from docx.shared import Pt

def export_docx(patient_name: str, encounter_date: str, narrative_text: str, bundle: dict) -> bytes:
    doc = Document()
    title = doc.add_paragraph()
    run = title.add_run("Operative Note")
    run.bold = True
    run.font.size = Pt(14)
    doc.add_paragraph("")
    for para in narrative_text.split("\n"):
        doc.add_paragraph(para)
    bio = io.BytesIO()
    doc.save(bio)
    bio.seek(0)
    return bio.read()

def export_json(patient_name: str, encounter_date: str, narrative_text: str, bundle: dict) -> bytes:
    payload = {
        "narrative": narrative_text,
        "cpt_codes": bundle.get("cpt_codes", []),
        "icd10_codes": bundle.get("icd10_codes", []),
        "totals": bundle.get("totals", {})
    }
    return json.dumps(payload, indent=2).encode("utf-8")
