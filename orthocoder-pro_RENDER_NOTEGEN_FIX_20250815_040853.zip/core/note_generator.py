from __future__ import annotations
import pandas as pd
from typing import List, Dict, Any

def _fmt_list(xs):
    return ", ".join(xs) if xs else "none"

def generate_note_text(wounds_df: pd.DataFrame, packs: List[str], bundle: Dict[str, Any]) -> str:
    lines = []
    lines.append("The operative field was identified, verified, prepped and draped in the usual sterile fashion.")
    for i, row in wounds_df.reset_index(drop=True).iterrows():
        site = str(row.get("site", f"Site {i+1}"))
        proc = str(row.get("procedure", ""))
        depth = str(row.get("depth", ""))
        area = float(row.get("area_cm2", 0) or 0)
        vasc = str(row.get("vascularity", ""))
        contam = str(row.get("contamination", ""))
        instr = _fmt_list(row.get("instruments", []))

        if proc == "Debridement":
            lines.append(f"At the {site}, debridement of {depth.lower()} was performed using {instr}; total surface area {area:.1f} cm². Tissue quality {vasc.lower()} with {contam.lower()} wound status.")
        elif proc == "Incision & Drainage":
            lines.append(f"At the {site}, incision and drainage was carried out through the indurated/infected area. Dissection was carried out to the extent of the spread of purulence. Culture taken and sent to lab. Purulence drained and loculations broken up as encountered. Instruments used included {instr}.")
        elif proc == "Joint Injection":
            lines.append(f"At the {site}, a sterile joint injection was performed. Instruments/needle set: {instr}.")
        elif proc == "Foreign Body Removal":
            lines.append(f"At the {site}, foreign body removal was accomplished using {instr}.")
        elif proc == "Wound Closure":
            lines.append(f"At the {site}, layered wound closure was performed as indicated.")
        else:
            lines.append(f"At the {site}, {proc.lower()} was performed.")
    lines.append("Hemostasis was achieved. Sterile dressing applied. The patient was transported to recovery in stable condition.")
    paragraph = " ".join(lines)
    paragraph += f"\n\nCPT: " + (", ".join(bundle.get("cpt_codes", [])) if bundle.get("cpt_codes") else "None")
    paragraph += f"\nICD-10: " + (", ".join(bundle.get("icd10_codes", [])) if bundle.get("icd10_codes") else "None")
    return paragraph
